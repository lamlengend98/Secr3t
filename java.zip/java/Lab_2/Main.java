package ABC_XYZ;
class Main{
	public static void main(String[] args){
		MyDate my = new MyDate();
		my.input();
	}
}