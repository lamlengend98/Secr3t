

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Classes cl = new Classes();
        cl.input();
        cl.show();
    }
    
}
