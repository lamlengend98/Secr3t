

class Lab_1_1{
	public static void main(String[] args){
		
		System.out.print("Ho va ten: Nguyen Thanh Lam\t");
		System.out.print("Ma sinh vien: AT130929\t");
		System.out.print("Lop: AT13K\t");
		System.out.print("Dia chi email: abc@gmail.com\t");
		
		
		for(int i = 9; i>= 1; i--){
			System.out.printf("%d bottles of beer on the wall, %d bottles of beer.\n",i,i);
			System.out.println("Take one down, pass it  around,");
		}
	}
}